export LD_LIBRARY_PATH=$HOME/rust/build/x86_64-unknown-freebsd/stage1/lib:$LD_LIBRARY_PATH
export RUSTC=$HOME/rust/build/x86_64-unknown-freebsd/stage1/bin/rustc
export XARGO_RUST_SRC=$HOME/rust-xargo/src
export PATH=$HOME/work/llvm-project/build/bin:$HOME/.cargo/bin:$HOME/rust/build/x86_64-unknown-freebsd/stage1/bin:$PATH
